# PHPUnit Wrapper

Builds:
* 9.0 ![Build Status](https://github.com/Codeception/phpunit-wrapper/workflows/CI/badge.svg?branch=9.0)
* 8.0 ![Build Status](https://github.com/Codeception/phpunit-wrapper/workflows/CI/badge.svg?branch=8.0)
* 7.1 ![Build Status](https://github.com/Codeception/phpunit-wrapper/workflows/CI/badge.svg?branch=7.1)
* 6.5 ![Build Status](https://github.com/Codeception/phpunit-wrapper/workflows/CI/badge.svg?branch=6.5)
* 6.0 ![Build Status](https://github.com/Codeception/phpunit-wrapper/workflows/CI/badge.svg?branch=6.0)


Codeception heavily relies on PHPUnit for running and managing tests.
Not all PHPUnit classes fit the needs of Codeception, that's why they were extended or redefined.

Releases follow major PHPUnit versions. 
